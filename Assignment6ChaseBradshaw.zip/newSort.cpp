#include <iostream>
#include <fstream>
#include <ctime>

using namespace std;

void BubbleSort(double myArray[], int size){
    for(int i=0; i<size; i++){
        double temp = myArray[0];
        //int temp = 0;
        for(int j=i;j<size-1;++j){
            if(myArray[j]>myArray[j+1]){
                temp = myArray[j+1];
                myArray[j+1] = myArray[j];
                myArray[j] = temp;
            }
        }
    }
    //for (int i=0; i<size; i++){
        //cout<<"PRINT: "<<myArray[i]<<endl;
    //}
}
void insertSort(double myArray[], int size){
    for(int j = 1; j < size; ++j){
        double temp = myArray[j];
        int k = j;
        while (k>0 && myArray[k-1]>=temp){
            myArray[k] = myArray[k-1];
            --k;
        }
        myArray[k] = temp;
    }

}

//helper method for quick sort
void swap(double*a, double*b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

//helper method for qucik sort
int partition(double myArray[], int low, int high){
    int l = (low - 1);
    int pivotVar = myArray[high]; //pivot variable used for swith sorting
    for (int i = low; i<= (high-1); ++i){
        //if the curr element is smaller than the pivotVar
        if(myArray[i] < pivotVar){
            ++i;
            swap(&myArray[l], &myArray[i]);
        }
    }
    swap(&myArray[l + 1], &myArray[high]);
    return (l+1);
}

//quick sort slightly modified code from Geeks for Geeks
//https://www.geeksforgeeks.org/quick-sort/
void quickSort(double myArray[], int low, int high){
    //low is the first index and high is the last
    if(low<high){
        //not double becuase index is int
        int partitionIndex = partition(myArray, low, high);

        quickSort(myArray,low, partitionIndex-1);
        quickSort(myArray, partitionIndex+1, high);

    }
}
//helper functionf for merge sort
void mergeFunction(double myArray[], int left, int middle, int right){



    //creating emtpy arrays to have data be coppied in to
    double leftArray[middle - left +1];
    double rightArray[right - middle];

    int n1 = middle - left +1;
    int n2 = right - middle;


    for (int i = 0; i < n1; i++)
        leftArray[i] = myArray[left + i];
    for (int j = 0; j < n2; j++)
        rightArray[j] = myArray[middle + 1+ j];

     int i = 0;
     int j = 0;
     int k = 1;

    //this part is straight from Geeks for Geeks, I saw the way they did it
    //and could not think of a better way
    while (i < n1 && j < n2)
    {
        if (leftArray[i] <= rightArray[j])
        {
            myArray[k] = leftArray[i];
            i++;
        }
        else
        {
            myArray[k] = rightArray[j];
            j++;
        }
        k++;
    }

}

//merge sort modified code from Geeks for Geeks
//geeksforgeeks.org/merge-sort/
void mergeSort(double myArray[], int left, int right){
    if(left<right){

        //find middle
        int middle = (left+right)/2;

        //split again
        mergeSort(myArray, left, middle);
        mergeSort(myArray, middle+1, right);

        //merge together
        mergeFunction(myArray, left, middle, right);


    }
}



int main(int argc, char **argv){
    //reads the first line of the file only so the program knows how big to make the file
    std::ifstream fin(argv[1]);
    int numItems = 0;
    fin>>numItems;
    fin.close();

    double myArray [numItems];

    int counter = 0;
    double d;
    ifstream fin2;
    fin2.open(argv[1]);
    //std::ifstream fin2(argv[1]);


    while(fin2>>d){
        if(counter>0){
            myArray[counter] = d;
            cout<<myArray[counter]<<endl;
        }
        else{
            fin2>>d;
        }
        counter++;
    }
    clock_t timerStart = clock();
    BubbleSort(myArray,numItems);
    clock_t timerEnd = clock();
    double timeInHuman = (timerEnd - timerStart) / CLOCKS_PER_SEC;
    cout<<"TIME: "<<timeInHuman<<endl;

    insertSort(myArray,numItems);
    quickSort(myArray,0,numItems);
    mergeSort(myArray,0,numItems-1);
    //for (int i=0; i<numItems; i++){
        //cout<<"PRINT: "<<myArray[i]<<endl;
    //}

}
