Chase Bradshaw
002317872
cbradshaw@chapman.edu
CPSC 350 Section 2
Assignment 6

files submitted:
newSort.cpp
Paper.pdf (made with TeX)

All code compiles correctly and does not encounter any runtime errors.
Small imperfections with Quick and Merge sort, as sometimes data will not be sorted.

Sources:
Much of the code was given in class
https://www.geeksforgeeks.org/merge-sort/
https://www.geeksforgeeks.org/quick-sort/
https://www.tutorialspoint.com/c_standard_library/c_function_clock.htm
https://www.geeksforgeeks.org/clock-function-in-c-c/
http://www.cplusplus.com/reference/ctime/clock/
