#include <fstream>
#include <iostream>
#include "GenQueue.h"
using namespace std;



int main(int argc, char const *argv[]) {
    string fileName = argv[1];
    string line = "";
    fstream stream;
    stream.open(fileName);
    while(getline(stream,line)){
        string parse = line;
        //add to queue
    }



    //int nextStudent = queue.pop();
    //int currentStudentsTime = queue.pop();
    //cout<< "Entered: "<< argv[1]<<endl;
    //calcThings();
    return 0;
}

void calcThings(){

    int numWindows = 1; //queue.pop();
    int nextStudentArrival = 1;
    int timeCounter = 0;
    int studentsInLine = 0;
    int windowsOpen = numWindows;

    while(false /*GenQueue.isEmpty()*/==false){
        timeCounter++;
        nextStudentArrival = 1;//queue.pop();
        studentsInLine = 1;//queue.pop();
        if(nextStudentArrival=timeCounter && windowsOpen<0){
            for(int i=0; i<=studentsInLine; i++){

            }
        }
        if(studentsInLine<windowsOpen){
            studentsInLine=0;

        }

    }
}
