#include <iostream>

using namespace std;

template<class T>
class ListNode{
public:
    T *data;
    ListNode *next;
    ListNode *prev;

    ListNode();
    ListNode(T* d);
    ~ListNode();
};
//constructor
template<class T>
ListNode<T>::ListNode(){

}
//parameter constructor
template<class T>
ListNode<T>::ListNode(T *d){
    data = d;
    next = NULL;
    prev = NULL;
}
//destructor
template<class T>
ListNode<T>::~ListNode(){
    next = NULL;
    prev = NULL;
}
