Chase Bradshaw
002317872
CPSC 350
Assignment 4

files:
ListNode.h
GenLinkedList.h
GenQueue.h
Registrar.cpp

Files ListNode.h, GenLinkedList.h, GenQueue.h, have all been written to completion.
Registrar.cpp compiles, but does not execute many of the requirements from this assignment  
