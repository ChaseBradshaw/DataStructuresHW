#include "GenLinkedList.h"

using namespace std;

template <class T>
class GenQueue
{
public:
    GenQueue();
    ~GenQueue();

    void insert(T *val);
    T* remove();
    T* peek();
    void printQ();
    int size;
    bool isEmpty();

    //creates the actual list
    GenLinkedList<T> *LinkedList;
};

template <class T>
GenQueue<T>::GenQueue(){
    LinkedList = new GenLinkedList<T>();
    size = 0;
}

template <class T>
GenQueue<T>::~GenQueue(){
    delete LinkedList;
}

template <class T>
void GenQueue<T>::insert(T *val){
    LinkedList.insertBack(val);
}

template <class T>
T* GenQueue<T>::remove(){
    T *tempNode = LinkedList.removeFront();
    return tempNode;
}

template <class T>
T* GenQueue<T>::peek(){
    //pointer to front of LinkedList then to value store in data
    return (LinkedList->front->data);
}

template <class T>
void GenQueue<T>::printQ(){
    cout<<LinkedList.printList();
}

template <class T>
bool GenQueue<T>::isEmpty(){
    if (size==0){
        return true;
    }
    else{
        return false;
    }
}
