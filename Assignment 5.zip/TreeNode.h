//Chase Bradshaw
#include <iostream>

using namespace std;

template<class T>
class TreeNode
{
    public:
        TreeNode();
        TreeNode(int k); //k=key, which in this example is also the value (data)
        ~TreeNode(); //when creating a template class destructor must me virtual

        T key;
        TreeNode<T> *left;
        TreeNode<T> *right;

};

template <class T>
TreeNode<T>::TreeNode(){

    key = 0; //changed from null to 0
    left = NULL;
    right = NULL;
}

//parameter constructor
template <class T>
TreeNode<T>::TreeNode(int k){
    key = k;
    left = NULL;
    right = NULL;
}

//destructor
template<class T>
TreeNode<T>::~TreeNode(){
    //you can research this
    //maybe do reasearch on this bitch
    delete key;
    delete left;
    delete right;
}
