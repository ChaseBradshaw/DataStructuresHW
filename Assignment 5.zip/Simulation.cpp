#include <iostream>
#include "Simulation.h"

using namespace std;

Simulation::Simulation(){

}

Simulation::~Simulation(){
    
}

void Simulation::printStudents(){

}

void Simulation::printFaculty(){

}

void Simulation::findStudent(){

}
void Simulation::findFaculty(){

}
void Simulation::StudentToFaculty(){

}
void Simulation::FacutlyToStudent(){

}
void Simulation::addStudent(){

}
void Simulation::deleteStudent(){

}
void Simulation::addFaculty(){

}
void Simulation::deleteFaculty(){

}
void Simulation::changeAdvisor(){

}
void Simulation::removeAdvisor(){

}
void Simulation::rollback(){

}
void Simulation::exit(){

}
