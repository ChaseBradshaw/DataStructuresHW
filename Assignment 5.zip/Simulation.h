#include<iostream>
#include"BST.h"
#include"Student.h"
#include"Faculty.h"

using namespace std;
class Simulation{
public:

    Simulation();
    ~Simulation();
    void printStudents();
    void printFaculty();
    void findStudent();
    void findFaculty();
    void StudentToFaculty();
    void FacutlyToStudent();
    void addStudent();
    void deleteStudent();
    void addFaculty();
    void deleteFaculty();
    void changeAdvisor();
    void removeAdvisor();
    void rollback();
    void exit();

};
