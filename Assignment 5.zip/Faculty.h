#include <iostream>
#include "GenLinkedList.h"

using namespace std;

class Faculty{
public:
    //constructors destructors
    Faculty();
    Faculty(int id, string name, string level, string department);
    ~Faculty();
    //variables
    int id;
    string name;
    string level;
    string department;
    GenLinkedList<int> list;
    //other methods
    int FGetID();
    string FGetName();
    string FGetLevel();
    string FGetDepartment();



};
