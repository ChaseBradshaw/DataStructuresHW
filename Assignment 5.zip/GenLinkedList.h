#include "ListNode.h"
#include <iostream>

using namespace std;
template<class T>
class GenLinkedList{
/*private:
    ListNode *front;
    unsigned int size;
*/
public:
    //from class change all ints to work with template

    GenLinkedList();
    ~GenLinkedList();
    unsigned int size;

    //add back to all fronts
    void insertFront(T d);
    //add insertBack
    void insertBack(T *d);
    T* removeFront();
    //add removeBack
    T removeBack();

    //int deletePos(int pos); no longer needed
    int find(T d);

    //methods added from class
    bool isEmpty();
    void printList();
    unsigned int getSize();

    //these list nodes must be declared here so that I can reference the front and back of the list later on
    ListNode<T> *front;
    ListNode<T> *back;
};
//constructor
template<class T>
GenLinkedList<T>::GenLinkedList(){
    front = NULL;
    back = NULL;
    size = 0;
}
//destructor
template<class T>
GenLinkedList<T>::~GenLinkedList(){
    //delete entire linked list
}

template<class T>
bool GenLinkedList<T>::isEmpty(){
    if(size==0){
        return true;
    }
    else{
        return false;
    }
}


template<class T>
void GenLinkedList<T>::printList(){
    ListNode<T> *current = front;
    while(current != NULL){
        cout<<current->next<<" "<<endl;
        current = current->next;
    }
}

template<class T>
void GenLinkedList<T>::insertFront(T val){
    //create new node with value from val
    ListNode<T> *node = new ListNode<T>(val);
    //if(isEmpty()==false)
    if(size != 0){
        node->next = front;
        front->prev = node;
        front = node;
    }
    //jaunt is empty
    else{
        back = node;
    }
    ++size;
}

template<class T>
void GenLinkedList<T>::insertBack(T *val){
    ListNode<T> *backNode = new ListNode<T>(val);
    back->next = backNode;
    backNode->prev = back;
    back = backNode;
    ++size;
}

template<class T>
T* GenLinkedList<T>::removeFront(){
    ListNode<T> *frontNode = front;
    front = front->next;
    T *tempNode = frontNode->data;
    frontNode->next= NULL;
    --size;
    //returns the value of the removed node
    return tempNode;
}

template<class T>
T GenLinkedList<T>::removeBack(){
    ListNode<T> *backNode = back;
    back = back->prev;
    T tempNode = backNode->data;
    backNode->prev = NULL;
    delete backNode;
    --size;
    return tempNode;
}

template<class T>
int GenLinkedList<T>::find(T val){
    ListNode<T> *curr = front;
    int counter;
    while(curr!=NULL){
        if(curr->data == val){
            return counter;
        }
    }
    return -1;
}

template<class T>
unsigned int GenLinkedList<T>::getSize(){
    return size;
}
