#include <iostream>
#include <string>


using namespace std;

class Student{

public:
    //constructors destructors
    Student();
    Student(int id, string name, string grade, string major, double gpa, int advisor);
    ~Student();
    //variables
    int id;
    string name;
    string grade;
    string major;
    double gpa;
    int advisor;
    //other methods
    int GetID();
    string GetName();
    string GetGrade();
    string GetMajor();
    double GetGPA();
    int GetAdvisor();

};
