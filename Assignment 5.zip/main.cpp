#include <iostream>
#include "simulation.h"

using namespace std;

int main(){
    int userChoice = 0;

    cout<<"1. Print all students and their information (sorted by ascending id #) "<<endl;
    cout<<"2. Print all faculty and their information (sorted by ascending id #) "<<endl;
    cout<<"3. Find and display student information given the students id "<<endl;
    cout<<"4. Find and display faculty information given the faculty id "<<endl;
    cout<<"5. Given a student’s id, print the name and info of their faculty advisor "<<endl;
    cout<<"6. Given a faculty id, print ALL the names and info of his/her advisees. "<<endl;
    cout<<"7. Add a new student "<<endl;
    cout<<"8. Delete a student given the id "<<endl;
    cout<<"9. Add a new faculty member "<<endl;
    cout<<"10. Delete a faculty member given the id. "<<endl;
    cout<<"11. Change a student’s advisor given the student id and the new faculty id. "<<endl;
    cout<<"12. Remove an advisee from a faculty member given the ids "<<endl;
    cout<<"13. Rollback "<<endl;
    cout<<"14. Exit "<<endl;

    cin>>userChoice;


    Simulation Sim;
    if (userChoice==1){
        Sim.printStudents();
    }
    else if(userChoice==2){
        Sim.printFaculty();
    }
    else if(userChoice==3){
        Sim.findStudent();
    }
    else if(userChoice==4){
        Sim.findFaculty();
    }
    else if(userChoice==5){
        Sim.StudentToFaculty();
    }
    else if(userChoice==6){
        Sim.FacutlyToStudent();
    }
    else if(userChoice==7){
        Sim.addStudent();
    }
    else if(userChoice==8){
        Sim.deleteStudent();
    }
    else if(userChoice==9){
        Sim.addFaculty();
    }
    else if(userChoice==10){
        Sim.deleteFaculty();
    }
    else if(userChoice==11){
        Sim.changeAdvisor();
    }
    else if(userChoice==12){
        Sim.removeAdvisor();
    }
    else if(userChoice==13){
        Sim.rollback();
    }
    else if(userChoice==14){
        Sim.exit();
    }


}
