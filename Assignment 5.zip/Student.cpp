#include <iostream>
#include <string>

#include "student.h"

using namespace std;

Student::Student(){
    id = 0;
    name = "";
    grade = "";
    major = "";
    gpa = 0.0;
    advisor = 0;
}

Student::Student(int id, string name, string grade, string major, double gpa, int advisor){
    this->id = id;
    this->name = name;
    this->grade = grade;
    this->major = major;
    this->gpa = gpa;
    this->advisor = advisor;

}

int Student::GetID(){
    return id;
}

string Student::GetName(){
    return name;
}

string Student::GetGrade(){
    return grade;
}

string Student::GetMajor(){
    return major;
}

double Student::GetGPA(){
    return gpa;
}

int Student::GetAdvisor(){
    return advisor;
}

Student::~Student(){

}
