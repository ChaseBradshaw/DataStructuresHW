Chase Bradshaw
002317872
cbradshaw@chapman.edu
CPSC 350 Section 2
Assignment 5

Instructions to run:
g++ *.cpp
./a.out


Student (cpp and h) files have been completed.  Faculty (cpp and h) files have been completed.
BST (cpp and h) files have been completed.  GenLinkedList used from previous assignment.
Main and Simulation have the start of the solution to this assignment, however they do not contain the full solution.
All files compile and run.

Included files:
BST.h
Faculty.h
Faculty.cpp
Student.h
Student.cpp
TreeNode.h
GenLinkedList.h
ListNode.h
Simulation.h
Simulation.cpp
main.cpp
README.txt
