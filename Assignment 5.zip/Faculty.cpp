#include <iostream>
#include "Faculty.h"

using namespace std;

//constructor
Faculty::Faculty(){
    id = 0;
    name = "";
    level = "";
    department = "";
}

//parameter constructor
Faculty::Faculty(int id, string name, string level, string department)
{
    this->id = id;
    this->name = name;
    this->level = level;
    this->department = department;
}

Faculty::~Faculty(){

}

int Faculty::FGetID(){
    return id;
}

string Faculty::FGetName(){
    return name;
}

string Faculty::FGetLevel(){
    return level;
}

string Faculty::FGetDepartment(){
    return department;
}
